#Final Project

This project goes over the Longest Common Subsequence problem that is listed in the class instructions.

Given two string sequences, compute and print out the longest common subsequence. The implementation should include a function with the following signature.

String LongestCommonSubsequence(String x, String y)

x and y: are the two input strings

The function should return a string that contains the longest common subsequence between the two inputs.

Note: If you use C++, you can use the STL string data type.

#Installation

Installed Oracle OpenJDK 17.0.2

#Usage

-Open File in IDE(preferably Intellij)

-Change variable wordX and wordY to the two string you want to compare in the main.
-Click run and wait for compile.

-LCS should be printed in the terminal.

#Running Tests

Can run different tests by changing variable wordX and wordY to different words.
