package com.company;

public class Main {
    public static String longestCommonSubsequence(String sOne, String sTwo)
    {
        int m = sOne.length();
        int n = sTwo.length();
        String[][] B = new String[m+1][n+1]; //decision array of arrrows.
        int[][] L = new int[m+1][n+1];       //array of numbers, B[m][n] will tell us lcs/

        //set 0 to all the rows and columns
        for(int i = 0; i <= m; i++) {
            L[i][0] = 0;
        }
        for(int j = 0; j <= n; j++){
            L[0][j] = 0;
        }

        //set number and arrow based on iff row and col match or if u need to move up or left
        for(int i = 1; i <= m; i++){
            for(int j = 1; j <= n; j++){
                if(sOne.charAt(i-1) == sTwo.charAt(j-1)){    //match
                    L[i][j] = L[i-1][j-1] + 1;
                    B[i][j] = "↖";
                }
                else if(L[i-1][j] >= L[i][j-1]) {           //if left is greater or equal than one on top
                    L[i][j] = L[i-1][j];
                    B[i][j] = "↑";
                }
                else {
                    L[i][j] = L[i][j-1];                    //other
                    B[i][j] = "←";
                }
            }
        }

        /*
        //Prints the numbers on the bottom up graph
        for(int i = 0; i <= m; i++){
            for(int j = 0; j <= n; j++){
            System.out.print(L[i][j]);
            }
            System.out.println();
        }

        //Prints arrow in bottom up graph
        for(int i = 0; i <= m; i++){
            for(int j = 0; j <= n; j++){
                System.out.print(B[i][j]);
            }
            System.out.println();
        }
         */

        //uses arrow to add all lcs letters to a string and return for main to print.
        String fOutput = printLCS(sOne, sTwo, m, n, B);
        return fOutput;
    }

    public static String printLCS(String sOne, String sTwo, int i, int j, String[][] d){

        String o = "";

        //when hit 0 then ur done.
        if(i == 0 || j == 0){
            return o;
        }
        // if this, then we move diagonal + print what's after
        // this is because we are going backwards.
        if(d[i][j] == "↖"){
            return printLCS(sOne,sTwo,i-1,j-1,d) + String.valueOf(sOne.charAt(i-1));
        }
        //move up
        else if (d[i][j] == "↑") {
            return printLCS(sOne,sTwo, i-1, j,d);
        }
        //move left
        else{
            return printLCS(sOne,sTwo,i,j-1,d);
        }


    }

    public static void main(String[] args) {
        //put strings u want here.
        String wordX = "ABCBDAB";
        String wordY = "BDCABA";

        System.out.println("Your longest common subsequence is: ");

        //call function into string and then print.
        String lcs = longestCommonSubsequence(wordX,wordY);
        System.out.println(lcs);
    }
}
